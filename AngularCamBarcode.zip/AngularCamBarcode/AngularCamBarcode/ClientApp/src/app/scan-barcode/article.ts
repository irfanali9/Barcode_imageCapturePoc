export interface Article {
  ean: string;
  name: string;
  image: string;
  price: number;
}
