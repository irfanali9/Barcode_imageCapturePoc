import { Component, Input, OnInit } from '@angular/core';
import { Article } from '../scan-barcode/article';

@Component({
  selector: 'app-shopping-cart-item',
  templateUrl: './shopping-cart-item.component.html',
  styleUrls: ['./shopping-cart-item.component.css']
})
export class ShoppingCartItemComponent implements OnInit {

  constructor() {
  }

  @Input()
  article: Article | undefined;

  @Input()
  count: number | undefined;

  ngOnInit(): void {
  }

}
